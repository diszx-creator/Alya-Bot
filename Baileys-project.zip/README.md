# Alya Baileys

Premium Anime WhatsApp Library.

## Install

npm install

## Run

node index.js

## Pairing

Masukkan nomor owner pada .env.

## Plugin

Tambah plugin baru di folder src/plugins.

## Command

Gunakan prefix sesuai .env.