const cooldowns = new Map()

module.exports = (id, seconds) => {
  if (cooldowns.has(id)) return false

  cooldowns.set(id, true)

  setTimeout(() => cooldowns.delete(id), seconds * 1000)

  return true
}