const map = new Map()

module.exports = (id) => {
  const current = map.get(id) || 0

  map.set(id, current + 1)

  if (map.get(id) > 10) {
    return false
  }

  setTimeout(() => {
    map.delete(id)
  }, 10000)

  return true
}