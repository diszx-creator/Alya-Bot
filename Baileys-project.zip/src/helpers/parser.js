module.exports = {
  getText(message) {
    return message?.conversation || ''
  }
}