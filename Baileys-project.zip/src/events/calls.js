module.exports = (sock) => {
  sock.ev.on('call', async (data) => {
    console.log('[CALL EVENT]', data)
  })
}