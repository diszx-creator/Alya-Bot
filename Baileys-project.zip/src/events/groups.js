module.exports = (sock) => {
  sock.ev.on('group-participants.update', async (data) => {
    console.log('[GROUP UPDATE]', data)
  })
}