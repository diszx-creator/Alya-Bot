module.exports = (sock) => {
  sock.ev.on('presence.update', (data) => {
    console.log('[PRESENCE]', data)
  })

  sock.ev.on('contacts.upsert', (data) => {
    console.log('[CONTACTS]', data.length)
  })

  sock.ev.on('chats.upsert', (data) => {
    console.log('[CHATS]', data.length)
  })
}