const commandHandler = require('../handler/commandHandler')

module.exports = (sock) => {
  sock.ev.on('messages.upsert', async ({ messages }) => {
    const m = messages[0]

    if (!m.message) return

    await commandHandler(sock, m)
  })
}