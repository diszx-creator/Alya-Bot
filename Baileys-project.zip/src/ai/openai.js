module.exports = async (prompt) => {
  return `AI Response: ${prompt}`
}