module.exports = {
  prefix: process.env.PREFIX || '.',
  owner: process.env.OWNER,
  botName: process.env.BOT_NAME || 'Alya',
  pairingCode: process.env.PAIRING_CODE || 'ALYAMOON'
}