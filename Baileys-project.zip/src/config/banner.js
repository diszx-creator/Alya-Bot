const figlet = require('figlet')
const gradient = require('gradient-string')

module.exports = () => {
  console.log(
    gradient.pastel.multiline(
      figlet.textSync('Alya', {
        horizontalLayout: 'default'
      })
    )
  )

  console.log(
    gradient.instagram('\nPremium Anime WhatsApp Library • diszxe-recode\n')
  )
}