require('dotenv').config()

const start = require('./core/startup')

start()