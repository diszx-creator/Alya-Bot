module.exports = {
  command: 'menu',

  execute: async ({ sock, m }) => {
    const text = `
╭───〔 Alya Menu 〕
│ .ping
│ .menu
│ .ai
╰────────────
`

    await sock.sendMessage(m.key.remoteJid, {
      text
    })
  }
}