const askAI = require('../ai/openai')

module.exports = {
  command: 'ai',

  execute: async ({ sock, m, args }) => {
    const prompt = args.join(' ')

    const result = await askAI(prompt)

    await sock.sendMessage(m.key.remoteJid, {
      text: result
    })
  }
}