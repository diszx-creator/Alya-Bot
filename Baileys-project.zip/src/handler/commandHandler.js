const fs = require('fs')
const path = require('path')

const settings = require('../config/settings')

module.exports = async (sock, m) => {
  const body = m.message?.conversation || ''

  if (!body.startsWith(settings.prefix)) return

  const args = body.slice(1).trim().split(/ +/)

  const command = args.shift().toLowerCase()

  const files = fs.readdirSync(path.join(__dirname, '../plugins'))

  for (const file of files) {
    const plugin = require(`../plugins/${file}`)

    if (plugin.command === command) {
      return plugin.execute({ sock, m, args })
    }
  }
}