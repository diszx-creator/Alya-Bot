const chalk = require('chalk')

module.exports = {
  red: chalk.red,
  green: chalk.green,
  blue: chalk.blue,
  yellow: chalk.yellow
}