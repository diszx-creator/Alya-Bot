const fs = require('fs-extra')

module.exports = async () => {
  await fs.copy('./src/storage/session', './backup/session')
}