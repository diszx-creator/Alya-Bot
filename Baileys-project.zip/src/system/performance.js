module.exports = () => {
  setInterval(() => {
    const used = process.memoryUsage().heapUsed / 1024 / 1024

    console.log(`[MEMORY] ${used.toFixed(2)} MB`)
  }, 10000)
}