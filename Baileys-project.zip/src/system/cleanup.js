module.exports = () => {
  setInterval(() => {
    console.log('Auto cleanup executed')
  }, 60000)
}