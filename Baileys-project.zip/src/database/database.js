const db = {
  users: {},
  groups: {}
}

module.exports = db