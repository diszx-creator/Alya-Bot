const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion
} = require('@whiskeysockets/baileys')

const P = require('pino')
const qrcode = require('qrcode-terminal')

const logger = require('../logger/logger')
const loadEvents = require('../events/connection')
const loadMessages = require('../events/messages')
const loadGroups = require('../events/groups')
const loadCalls = require('../events/calls')

const settings = require('../config/settings')

module.exports = async () => {
  const { state, saveCreds } = await useMultiFileAuthState('./src/storage/session')

  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: false,
    logger: P({ level: 'silent' })
  })

  if (!sock.authState.creds.registered) {
    const code = await sock.requestPairingCode(settings.owner)

    logger.success(`Custom Pairing: ${settings.pairingCode}`)
    logger.info(`Generated Pairing Code: ${code}`)
  }

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', async (update) => {
    const { connection, qr, lastDisconnect } = update

    if (qr) {
      qrcode.generate(qr, { small: true })
    }

    if (connection === 'open') {
      logger.success('Connected to WhatsApp')
    }

    if (connection === 'close') {
      const reason = lastDisconnect?.error?.output?.statusCode

      if (reason !== DisconnectReason.loggedOut) {
        logger.warn('Reconnecting...')
        module.exports()
      }
    }
  })

  loadEvents(sock)
  loadMessages(sock)
  loadGroups(sock)
  loadCalls(sock)

  global.sock = sock

  return sock
}