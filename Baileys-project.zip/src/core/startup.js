const banner = require('../config/banner')
const connect = require('./socket')
const logger = require('../logger/logger')
const integrity = require('../security/integrity')

module.exports = async () => {
  banner()

  integrity()

  logger.info('Starting Alya System...')

  await connect()
}