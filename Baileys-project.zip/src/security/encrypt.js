const crypto = require('crypto')

module.exports = {
  encode(text) {
    return crypto.createHash('sha256').update(text).digest('hex')
  }
}