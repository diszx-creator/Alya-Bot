module.exports = (input) => {
  return typeof input === 'string'
}