const fs = require('fs')

module.exports = () => {
  if (!fs.existsSync('./package.json')) {
    throw new Error('Integrity failed')
  }
}