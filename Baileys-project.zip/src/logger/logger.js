const chalk = require('chalk')

module.exports = {
  info: (...msg) => console.log(chalk.cyan('[INFO]'), ...msg),
  error: (...msg) => console.log(chalk.red('[ERROR]'), ...msg),
  warn: (...msg) => console.log(chalk.yellow('[WARN]'), ...msg),
  success: (...msg) => console.log(chalk.green('[SUCCESS]'), ...msg)
}